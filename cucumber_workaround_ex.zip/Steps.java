package stepDefinition;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps {
	public static WebDriver driver;

	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page() {
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.naukri.com");
	}

	@When("^User Navigate to LogIn Page$")
	public void user_Navigate_to_LogIn_Page() {
		driver.findElement(By.xpath("//div[text()= 'Login']")).click();
	}

	/*@When("^User enters Credentials to LogIn$")
	public void user_enters_testuser__and_Test(DataTable usercredentials) throws Throwable {
		//List<List<String>> data = usercredentials.raw();
		List<List<String>> list = usercredentials.asLists(String.class);
		for(int i=0; i<list.size(); i++) { //i starts from 1 because i=0 represents the header
			driver.findElement(By.xpath("//input[contains(@placeholder,'active Email ID / Username')]")).sendKeys(list.get(i).get(0)); 
			driver.findElement(By.xpath("//input[contains(@placeholder,'password')]")).sendKeys(list.get(i).get(1));
			driver.findElement(By.xpath("//button[text()='Login']")).click();
		}

	}*/
	//Scenario outline
	@When("^User enters Credentials <username> and <password>$")
	public void user_enters_testuser__and_Test(String username , String password) {
		
		driver.findElement(By.xpath("//input[contains(@placeholder,'active Email ID / Username')]")).sendKeys(username); 
	    driver.findElement(By.xpath("")).sendKeys(password);
	    driver.findElement(By.xpath("//button[text()='Login']")).click();
	}

	@Then("^Message displayed Login-fail Successfully$")
	public void message_displayed_Login_Successfully() {
		System.out.println("Login Successfully");
	}

	//	@When("^User LogOut from the Application$")
	//	public void user_LogOut_from_the_Application() {
	//		driver.findElement (By.xpath(".//*[@id='account_logout']/a")).click();
	//	}
	//
	//	@After("^Message displayed Login Successfully$")
	//	public void message_displayed_Successfully(){
	//		System.out.println("Login Successfully");
	//	}
}